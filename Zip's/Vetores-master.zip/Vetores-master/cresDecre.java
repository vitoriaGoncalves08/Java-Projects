import java.util.Scanner;
public class cresDecre {
	public static void main (String[]args) {
		Scanner ler = new Scanner (System.in);
		
		int [] A = new int [10];
		int [] B = new int [10];
		int [] C = new int [10];
		
		for (int i=0; i<10; i++) {
			System.out.println("Digite um n�mero: ");
			A [i]= ler.nextInt ();
			
			for (int j=0; j<2;j++) {
			

				for (int d=0; d<2;d++) {
					
				}
					System.out.println("A som�toria de " + A[i] + " � igual a: " + B[j]);
				
			System.out.println("   ");
			}
		}
	}
}
